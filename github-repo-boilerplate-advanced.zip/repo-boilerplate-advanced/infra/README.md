# Infra (Terraform) Skeleton
- Use workspaces: `dev`, `qa`, `prod`, and dynamic `pr-XXXX` for previews.
- Put variables into `*.tfvars` (e.g., `qa.tfvars`, `prod.tfvars`).

Example files:
- `main.tf` (providers, backend, modules)
- `variables.tf` / `outputs.tf`
- `versions.tf`
