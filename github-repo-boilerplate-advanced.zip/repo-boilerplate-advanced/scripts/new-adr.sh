#!/usr/bin/env bash
set -euo pipefail
TITLE="${1:-}"
if [ -z "$TITLE" ]; then
  echo "Usage: scripts/new-adr.sh "My Decision Title""; exit 1
fi
NUM=$(printf "%04d" $(($(ls docs/adr | grep -E '^[0-9]{4}-.*\.md$' | wc -l) + 1)))
SLUG=$(echo "$TITLE" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9]+/-/g;s/^-+|-+$//g')
FILE="docs/adr/${NUM}-${SLUG}.md"
cp docs/adr/template.md "$FILE"
sed -i.bak -e "s/\[NUMBER\]/$NUM/" -e "s/\[TITLE\]/$TITLE/" "$FILE"
rm -f "${FILE}.bak"
echo "Created $FILE"
