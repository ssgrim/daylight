# SLO Template
- **Service**: [name]
- **SLIs**: latency p95, availability, error rate
- **SLOs**: e.g., 99.9% monthly availability
- **Error Budget Policy**: restrict releases if budget is exhausted
