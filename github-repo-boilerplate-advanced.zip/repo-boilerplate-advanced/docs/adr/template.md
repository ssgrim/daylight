# ADR [NUMBER]: [TITLE]

- Status: Proposed | Accepted | Deprecated | Superseded
- Date: YYYY-MM-DD
- Deciders: [names/roles]
- Tags: [architecture, database, security, compliance]

## Context
[What problem are we solving? What constraints and forces matter?]

## Decision
[What is the decision and why?]

## Consequences
[Positive/negative outcomes, risks, follow-ups]

## Alternatives Considered
- Option A — pros/cons
- Option B — pros/cons
