# Architecture Decision Records (ADRs)
Use ADRs to document **why** we made important decisions.

Create a new ADR:
```bash
scripts/new-adr.sh "Use PostgreSQL for transactional storage"
```
