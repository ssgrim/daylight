# Change Management
- Release train cadence: weekly/biweekly
- Approvals: PR review + CI green + change ticket (if regulated)
- Canary strategy + rollback criteria
