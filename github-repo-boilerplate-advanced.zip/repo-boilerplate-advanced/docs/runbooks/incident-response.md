# Incident Response Runbook
- **Severities**: SEV1 (full outage) ... SEV4 (minor)
- **On-call**: [rotation link]
- **Triage**: capture timeline, impact, blast radius
- **Mitigation**: rollback, feature-flag kill switch, scale out
- **Communication**: internal channel + status page cadence
- **Postmortem**: within 48h; blameless; action items tracked
