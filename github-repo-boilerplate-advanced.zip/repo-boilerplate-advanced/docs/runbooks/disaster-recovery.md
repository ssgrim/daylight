# Disaster Recovery Playbook
- **RPO**: [target], **RTO**: [target]
- Backups: frequency, retention, encryption
- Restoration drills: quarterly
- Region/account failover steps
