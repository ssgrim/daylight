Be respectful. Assume good intent. Disagree constructively.
