---
name: Feature request
about: Suggest an idea for this project
labels: type-feature, priority-medium
---

**Problem / Opportunity**

**Proposed solution**

**Acceptance Criteria**
- [ ] 

**Observability**
- Metrics/Logs/Traces added?

**Risk/Compliance**
- Data classification:
- Permissions:
