---
name: RFC
about: Design proposal prior to implementation
labels: type-docs, adr
---
## Context
## Proposal
## Alternatives
## Impact (Perf, Cost, Security, Compliance)
## Observability Plan
