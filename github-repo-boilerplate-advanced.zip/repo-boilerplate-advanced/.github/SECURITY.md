# Security Policy
- Report via GitHub Security Advisories.
- Supported branches: `main`, `dev`.

## Hardening
- CodeQL, Dependabot, secret scanning
- IaC scanning (Checkov) and cost checks (Infracost)
