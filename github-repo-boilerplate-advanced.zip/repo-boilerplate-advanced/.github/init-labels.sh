#!/usr/bin/env bash
set -euo pipefail
if ! command -v gh >/dev/null 2>&1; then
  echo "GitHub CLI (gh) required"; exit 1
fi
REPO="${REPO:-$(gh repo view --json nameWithOwner -q .nameWithOwner)}"
jq -r 'to_entries[] | [.key, .value.color, .value.description] | @tsv' .github/labels.json | while IFS=$'\t' read -r name color desc; do
  if gh label view "$name" >/dev/null 2>&1; then
    gh label edit "$name" --color "$color" --description "$desc"
  else
    gh label create "$name" --color "$color" --description "$desc" || true
  fi
done
echo "Labels synced for $REPO"
