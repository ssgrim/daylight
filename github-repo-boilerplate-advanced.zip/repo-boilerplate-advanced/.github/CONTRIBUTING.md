# Contributing Guide

## Branching
- `main` = production, `dev` = integration
- `feature/*` for work, `hotfix/*` for urgent fixes

## Commits/PRs
- Conventional commits preferred (enforced by CI)
- Link issues: `Fixes #123`
- Include tests and docs

## Local Dev
- Use DevContainer/Codespaces when available
- `pre-commit` hooks recommended (`pipx install pre-commit && pre-commit install`)

## Security
- Never commit secrets; rotate keys if exposed
- Use private advisories for vulnerabilities
