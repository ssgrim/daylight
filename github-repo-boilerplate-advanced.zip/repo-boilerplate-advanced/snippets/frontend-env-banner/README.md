# Frontend Env/Version Banner (React + Vite)

## 1) Inject values at build (already handled by CI)
CI exports:
- `APP_ENV` = development|qa|production
- `APP_VERSION` = tag or short SHA
It also uploads `env.json` artifact you can host alongside static assets.

## 2) Vite define (optional if you prefer env.json fetch)
Add to `vite.config.ts`:
```ts
import { defineConfig } from 'vite'
export default defineConfig({
  define: {
    'import.meta.env.VITE_APP_ENV': JSON.stringify(process.env.APP_ENV || 'development'),
    'import.meta.env.VITE_APP_VERSION': JSON.stringify(process.env.APP_VERSION || '0.0.0'),
  }
})
```

## 3) Banner component
Copy `Banner.tsx` into your app and place it at the top of the layout.

## 4) Using env.json (static hosting)
On app start, fetch `/env.json` and display values if you prefer runtime config.
```ts
const cfg = await fetch('/env.json').then(r=>r.json())
```

