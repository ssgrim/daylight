import React from 'react';

export default function Banner() {
  const env = (import.meta as any).env?.VITE_APP_ENV || 'development';
  const version = (import.meta as any).env?.VITE_APP_VERSION || '0.0.0';
  const isProd = env === 'production';
  return (
    <div style={{
      padding: '6px 10px',
      fontSize: 12,
      display: 'flex',
      justifyContent: 'space-between',
      background: isProd ? '#f6f8fa' : (env === 'qa' ? '#fff3cd' : '#e6f7ff'),
      borderBottom: '1px solid #d0d7de'
    }}>
      <span>{isProd ? 'Production' : `${env.toUpperCase()} ENVIRONMENT`}</span>
      <span>Version: {version}</span>
    </div>
  );
}
