# [PROJECT_NAME]

[One-sentence pitch.]

> **Stack**: [TECH_STACK] · **Cloud**: [CLOUD] · **Deployment**: [SERVERLESS|CONTAINERIZED|HYBRID]

## Quick Start
1. Copy `.env.example` to `.env` and set values.
2. Run locally (example for Node):
   ```bash
   npm ci && npm run dev
   ```

## Environments & Versioning
- The CI injects `APP_ENV` and `APP_VERSION` into builds.
- A JSON file `env.json` is generated in CI for static hosting use.
- The sample React banner in `/snippets/frontend-env-banner` shows how to display this in your UI.

## Docs
- **ADRs**: `docs/adr/` (use `scripts/new-adr.sh` to create new decisions)
- **Runbooks**: `docs/runbooks/`
- **Observability**: `docs/observability/` (SLI/SLO templates)
- **Architecture**: `docs/architecture.mmd` (Mermaid C4-style)

## Infra
- Terraform skeleton under `/infra` with fmt/validate hooks in CI
- Infracost PR comments for cost diffs (requires `INFRACOST_API_KEY` secret)
- Checkov security scanning for IaC

## Compliance/Supply Chain
- SBOM generated via Syft and uploaded to PR artifacts
- Dependabot + CodeQL + secret scanning enabled

## Contributing
See [CONTRIBUTING.md](.github/CONTRIBUTING.md).

## License
Choose one in `/licenses` and rename to `LICENSE` in the repo root.
