import { createRequire } from "module"; const require = createRequire(import.meta.url);
var r=async t=>{if(t.requestContext.http.method==="POST"){let o=JSON.parse(t.body||"{}");return{statusCode:200,body:JSON.stringify({ok:!0,tripId:o.tripId||"demo"})}}return{statusCode:405,body:"Method Not Allowed"}};export{r as handler};
